border_radius = 15
width = 300
title_font_size = 20
icons_width = 38
icons_height = 38
